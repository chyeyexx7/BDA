from cassandra.cluster import Cluster

class CassandraClient:
    def __init__(self, hosts):
        self.cluster = Cluster(hosts, protocol_version=4)
        self.session = self.cluster.connect()
        self.init_tables()

    def init_tables(self):
        """
        This function initializes all the tables needed for cassandra to work. It will
        create the keyspaces and tables if they don't exist.
        """
        # Create the keyspace and the tables for cassandra
        keyspace_query = """
            CREATE KEYSPACE IF NOT EXISTS sensor 
            WITH replication = {'class': 'SimpleStrategy', 'replication_factor': 1};
            """
        self.session.execute(keyspace_query)

        # Create the table for min, max, avg temperature. The 
        table_query = """
            CREATE TABLE IF NOT EXISTS sensor.temperature (
                sensor_id int,
                temperature float,
                timestamp timestamp,
                PRIMARY KEY (sensor_id, timestamp)
            );
            """
        self.session.execute(table_query)  

        # Create the table for type count. It has type as primary key and a quantity which is couter
        # to easily increment the value after each new sensor.
        table_query = """
            CREATE TABLE IF NOT EXISTS sensor.quantity (
                type text PRIMARY KEY,
                quantity counter
            );
            """
        self.session.execute(table_query)

        # Create the table for battery. It contains the column battery_low which is a boolean.
        # It is used to avoid filtering battery_level < 0.2, as Cassandra has trouble querying
        # data by range. When inserting data to this table, it will check if battery_level < 0.2,
        # if it is, it will put battery_low as true, else false.
        table_query = """
            CREATE TABLE IF NOT EXISTS sensor.battery (
                sensor_id int,
                battery_level float,
                battery_low boolean,
                timestamp timestamp,
                PRIMARY KEY (battery_low, sensor_id, timestamp)
            );
            """
        self.session.execute(table_query)

    def get_session(self):
        return self.session
    
    def get_cluster(self):
        return self.cluster

    def close(self):
        self.cluster.shutdown()

    def execute(self, query):
        self.session.execute(query)
    
    def get_temperature_values(self):
        query = """
                SELECT sensor_id, AVG(temperature) AS avg_temp, MIN(temperature) AS min_temp, MAX(temperature) AS max_temp
                FROM sensor.temperature 
                GROUP BY sensor_id;
                """
        
        results = self.session.execute(query)

        sensors = []
        for row in results:
            sensor = {}
            sensor['id'] = row.sensor_id
            sensor['values'] = [
                {'max_temperature': row.max_temp,
                 'min_temperature': row.min_temp,
                 'average_temperature': row.avg_temp
                 }]
            sensors.append(sensor)

        result_json = {'sensors': sensors}

        return result_json
    
    def get_sensor_quantity(self):
        query = """
                SELECT * FROM sensor.quantity;
                """
        results = self.session.execute(query)
        
        return {'sensors': [{'type': sensor.type, 'quantity': sensor.quantity} for sensor in results]}

    def get_low_battery(self):
        query = """
                SELECT sensor_id, battery_level
                FROM sensor.battery 
                WHERE battery_low = true;
                """
        
        results = self.session.execute(query)

        sensors = []
        for row in results:
            sensor = {}
            sensor['id'] = row.sensor_id
            sensor['battery_level'] = round(row.battery_level, 2)
            sensors.append(sensor)

        result_json = {'sensors': sensors}

        return result_json
