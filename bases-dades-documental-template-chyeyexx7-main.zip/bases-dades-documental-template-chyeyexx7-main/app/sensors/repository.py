from fastapi import HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional

from . import models, schemas
from app.redis_client import RedisClient
from app.mongodb_client import MongoDBClient

import json

def get_sensor(db: Session, sensor_id: int) -> Optional[models.Sensor]:
    return db.query(models.Sensor).filter(models.Sensor.id == sensor_id).first()

def get_sensor_by_name(db: Session, name: str) -> Optional[models.Sensor]:
    return db.query(models.Sensor).filter(models.Sensor.name == name).first()

def get_sensors(db: Session, skip: int = 0, limit: int = 100) -> List[models.Sensor]:
    return db.query(models.Sensor).offset(skip).limit(limit).all()

def create_sensor(db: Session, sensor: schemas.SensorCreate, mongodb: MongoDBClient) -> models.Sensor:
    """
    Here we will add the sensor data and also the data for mongodb.
    In MongoDB we will create one collection per sensor type.
    """
    db_sensor = models.Sensor(name=sensor.name, type=sensor.type)
    db.add(db_sensor)
    db.commit()
    db.refresh(db_sensor)
   
    sensor_data = sensor.dict()
    # Delete longitude and latitude from sensor
    del sensor_data['longitude']
    del sensor_data['latitude']

    # Store longitude and latitute as GeoJSON
    location = {
        'type' : 'Point',
        'coordinates': [sensor.longitude, sensor.latitude]
        }
    sensor_data['location'] = location

    # Store sensor data in mongoDB
    mongodb.getDatabase('sensors')
    collection = mongodb.getCollection(sensor.type)
    # Create index for geolocalization
    collection.create_index([("location", "2dsphere")])
    mongodb.insertDoc(sensor_data)
    
    return db_sensor

def record_data(redis: RedisClient, sensor_id: int, data: schemas.SensorData) -> schemas.SensorData:
    db_sensordata = data
    redis.set(sensor_id, json.dumps(data.dict(exclude_none=True)))
    return db_sensordata

def get_data(redis: RedisClient, sensor_id: int) -> schemas.SensorData:
    db_sensordata = redis.get(sensor_id)
    if db_sensordata is None:
        raise HTTPException(status_code=404, detail="Sensor data not found")
    
    return json.loads(db_sensordata)

def delete_sensor(db: Session, mongodb: MongoDBClient, redis: RedisClient, sensor_id: int):
    db_sensor = db.query(models.Sensor).filter(models.Sensor.id == sensor_id).first()
    db.delete(db_sensor)
    db.commit()
    mongodb.getDatabase('sensors')
    mongodb.getCollection(db_sensor.type)
    mongodb.deleteDoc(db_sensor.name)
    redis.delete(sensor_id)
    return db_sensor


def get_sensors_near(mongodb: MongoDBClient, latitude: float, longitude: float, radius: float) -> List:
    return mongodb.findNear(latitude, longitude, radius)

def get_sensor_mongo(mongodb: MongoDBClient, name: str, collection: str):
    mongodb.getDatabase('sensors')
    mongodb.getCollection(collection)
    return mongodb.findDoc(name)
