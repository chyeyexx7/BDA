from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.redis_client import RedisClient
from app.mongodb_client import MongoDBClient
from . import models, schemas, repository


# Dependency to get db session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Dependency to get redis client
def get_redis_client():
    redis = RedisClient(host="redis")
    try:
        yield redis
    finally:
        redis.close()

# Dependency to get mongodb client
def get_mongodb_client():
    mongodb = MongoDBClient(host="mongodb")
    try:
        yield mongodb
    finally:
        mongodb.close()


router = APIRouter(
    prefix="/sensors",
    responses={404: {"description": "Not found"}},
    tags=["sensors"],
)

# 🙋🏽‍♀️ Add here the route to get all sensors
@router.get("")
def get_sensors(db: Session = Depends(get_db)):
    return repository.get_sensors(db)

# 🙋🏽‍♀️ Add here the route to get a list of sensors near to a given location
@router.get("/near")
def get_sensors_near(latitude: float, longitude: float, radius: float, db: Session = Depends(get_db), 
                     mongodb_client: MongoDBClient = Depends(get_mongodb_client),
                     redis_client: RedisClient = Depends(get_redis_client)):
    """
    Returns a list of sensors sorted by ascending order (distance).
    Because we have three data bases, in order to be able to extraft closest sensors from mongodb,
    firstly we have to get the sensors from mongodb, secondly use the 'name' inside mongodb documents
    to query in postgresql which has the index 'name'. Lastly, use the 'sensor_id' from postgresql
    to query in redis.
    """
    mongo_sensors = repository.get_sensors_near(mongodb=mongodb_client, latitude=latitude, longitude=longitude, radius=radius)
    if not mongo_sensors:
        raise HTTPException(status_code=404, detail="No sensors in data base")
    # Iterate over the mongo sensors and get sensor from postgresql, because it has the sensor_id
    sensors = [repository.get_sensor_by_name(db, sensor['name']) for sensor in mongo_sensors]
    # Iterate over the sensors above and get data from redis with key sensor_id
    for sensor in sensors:
        sensor_data = sensor.__dict__
        db_sensordata = repository.get_data(redis=redis_client, sensor_id=sensor_data['id'])
        sensor_data.update(db_sensordata)
    return sensors

# 🙋🏽‍♀️ Add here the route to get a sensor by id
@router.get("/{sensor_id}")
def get_sensor(sensor_id: int, db: Session = Depends(get_db), mongodb_client: MongoDBClient = Depends(get_mongodb_client),
               redis_client: RedisClient = Depends(get_redis_client)):
    """
    This API returns all data from sensor (SQL, Redis and Mongo)
    """
    db_sensor = repository.get_sensor(db, sensor_id)
    if db_sensor is None:
        raise HTTPException(status_code=404, detail="Sensor not found")
    db_sensordata = repository.get_data(redis=redis_client, sensor_id=sensor_id)
    db_sensor.__dict__.update(db_sensordata)
    db_mongo_sensor = repository.get_sensor_mongo(mongodb=mongodb_client, 
                                                  name=db_sensor.__dict__['name'], 
                                                  collection=db_sensor.__dict__['type']
                                                )
    db_sensor.__dict__.update(db_mongo_sensor)

    return db_sensor

# 🙋🏽‍♀️ Add here the route to create a sensor
@router.post("")
def create_sensor(sensor: schemas.SensorCreate, db: Session = Depends(get_db), mongodb_client: MongoDBClient = Depends(get_mongodb_client)):
    db_sensor = repository.get_sensor_by_name(db, sensor.name)
    if db_sensor:
        raise HTTPException(status_code=400, detail="Sensor with same name already registered")
    return repository.create_sensor(db=db, sensor=sensor, mongodb=mongodb_client)

# 🙋🏽‍♀️ Add here the route to delete a sensor
@router.delete("/{sensor_id}")
def delete_sensor(sensor_id: int, db: Session = Depends(get_db),
 redis_client: RedisClient = Depends(get_redis_client), mongodb_client: MongoDBClient = Depends(get_mongodb_client)):
    db_sensor = repository.get_sensor(db, sensor_id)
    if db_sensor is None:
        raise HTTPException(status_code=404, detail="Sensor not found")

    db_data = repository.get_data(redis=redis_client, sensor_id=sensor_id)
    if db_data is None:
        raise HTTPException(status_code=404, detail="Sensor has no data")
    
    return repository.delete_sensor(db=db, mongodb=mongodb_client, redis=redis_client, sensor_id=sensor_id)
    

# 🙋🏽‍♀️ Add here the route to update a sensor
@router.post("/{sensor_id}/data")
def record_data(sensor_id: int, data: schemas.SensorData, db: Session = Depends(get_db), redis_client: RedisClient = Depends(get_redis_client)):
    db_sensor = repository.get_sensor(db, sensor_id)
    if db_sensor is None:
        raise HTTPException(status_code=404, detail="Sensor not found")
    return repository.record_data(redis=redis_client, sensor_id=sensor_id, data=data)

# 🙋🏽‍♀️ Add here the route to get data from a sensor
@router.get("/{sensor_id}/data")
def get_data(sensor_id: int, db: Session = Depends(get_db), redis_client: RedisClient = Depends(get_redis_client)):    
    """
    In order to get all the data, first we have to query the sensor which contains
    the sensor name and sensor_id stored in the model, then query the dynamic
    data from redis client. 
    The result will be a dict containing both data, the static and dynamic.
    """
    db_sensor = repository.get_sensor(db, sensor_id)
    if db_sensor is None:
        raise HTTPException(status_code=404, detail="Sensor not found")
    db_sensordata = repository.get_data(redis=redis_client, sensor_id=sensor_id)
    db_sensor.__dict__.update(db_sensordata)
    return db_sensor
