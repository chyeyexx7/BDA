from fastapi import HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional

from . import models, schemas
from app.redis_client import RedisClient
from app.mongodb_client import MongoDBClient
from app.elasticsearch_client import ElasticsearchClient
from app.timescale import Timescale

import json

def get_sensor(db: Session, sensor_id: int) -> Optional[models.Sensor]:
    return db.query(models.Sensor).filter(models.Sensor.id == sensor_id).first()

def get_sensor_by_name(db: Session, name: str) -> Optional[models.Sensor]:
    return db.query(models.Sensor).filter(models.Sensor.name == name).first()

def get_sensors(db: Session, skip: int = 0, limit: int = 100) -> List[models.Sensor]:
    return db.query(models.Sensor).offset(skip).limit(limit).all()

def create_sensor(db: Session, sensor: schemas.SensorCreate, mongodb: MongoDBClient, esdb: ElasticsearchClient) -> schemas.Sensor:
    """
    Here we will add the data for the sensor, mongodb and elasticsearch.
    In MongoDB we will create one collection per sensor type.
    """
    db_sensor = models.Sensor(name=sensor.name, type=sensor.type)
    db.add(db_sensor)
    db.commit()
    db.refresh(db_sensor)
   
    sensor_data = sensor.dict()
    # Delete longitude and latitude from sensor
    del sensor_data['longitude']
    del sensor_data['latitude']

    # Store longitude and latitute as GeoJSON
    location = {
        'type' : 'Point',
        'coordinates': [sensor.longitude, sensor.latitude]
        }
    sensor_data['location'] = location

    # Store sensor data in mongoDB
    mongodb.getDatabase()
    collection = mongodb.getCollection(sensor.type)
    # Create index for geolocalization
    collection.create_index([("location", "2dsphere")])
    mongo_data = mongodb.insertDoc(sensor_data)

    # Store sensor data in elasticsearch
    es_data = {
        'name': sensor.name,
        'type': sensor.type,
        'description': sensor.description
    }
    esdb.index_document('sensors', es_data)

    # create keys for longitude and latitude, then remove location in order to pass test
    mongo_data['id'] = db_sensor.id
    mongo_data['longitude'] = mongo_data['location']['coordinates'][0]
    mongo_data['latitude'] = mongo_data['location']['coordinates'][1]
    del mongo_data['location']
    
    return mongo_data

def record_data(redis: Session, ts: Timescale, sensor_id: int, data: schemas.SensorData) -> schemas.SensorData:
    # Store last dynamyc data in redis and timeseries in timescale
    ts_query = f"""
                INSERT INTO sensor_data 
                (sensor_id, temperature, humidity, velocity, battery_level, last_seen) 
                VALUES (%s, %s, %s, %s, %s, %s)
                """
    values = (sensor_id, data.temperature, data.humidity, data.velocity, data.battery_level, data.last_seen)
    redis.set(sensor_id, json.dumps(data.dict(exclude_none=True)))
    ts.insert(ts_query, values)
    return redis.get(sensor_id)

def get_data(redis: RedisClient, sensor_id: int) -> schemas.SensorData:
    db_sensordata = redis.get(sensor_id)
    if db_sensordata is None:
        return {'message': 'no data'}
    
    return json.loads(db_sensordata)

def get_ts_data(ts: Timescale, sensor_id: int, from_date: str, end_date: str, bucket: int) -> schemas.SensorData:
    """
    Retrieve data from timescale grouped by bucket (it can be hour, day and week).
    """
    ts_query = f"""
        SELECT *
        FROM {bucket}
        WHERE sensor_id = {sensor_id}
            AND {bucket} BETWEEN time_bucket('1 {bucket}', '{from_date}'::timestamp)
            AND time_bucket('1 {bucket}', '{end_date}'::timestamp)
        ORDER BY {bucket} ASC;
    """

    ts.execute(ts_query)
    result = ts.getCursor().fetchall()

    return result

def delete_sensor(db: Session, mongodb: MongoDBClient, redis: RedisClient, esdb: ElasticsearchClient, ts: Timescale, sensor_id: int):
    """
    Delete all the data from sensor_id from mongo, model, redis , elasticsearch and timescale
    """
    db_sensor = db.query(models.Sensor).filter(models.Sensor.id == sensor_id).first()
    db.delete(db_sensor)
    db.commit()
    mongodb.getDatabase('sensors')
    mongodb.getCollection(db_sensor.type)
    mongodb.deleteDoc(db_sensor.name)

    # Delete dynamic data if the sensor has stored dynamyc data in redis
    if redis.get(sensor_id):
        redis.delete(sensor_id)

    esdb.delete_document('sensors', db_sensor.name)
    ts.delete_sensor('sensor_data', sensor_id)

    return db_sensor

def get_sensor_mongo(mongodb: MongoDBClient, name: str, collection: str) -> schemas.SensorCreate:
    """
    Retrieve sensor from mongo
    """
    mongodb.getDatabase()
    mongodb.getCollection(collection)
    doc = mongodb.findDoc(name)
    # Convert geolocalization to longitude and latitude in order to pass the tests
    doc['longitude'] = doc['location']['coordinates'][0] 
    doc['latitude'] = doc['location']['coordinates'][1]
    # delete geolocalization
    del doc['location']

    return doc

def search_sensors(db: Session, mongodb: MongoDBClient, esdb: ElasticsearchClient, query: str, size: int, search_type: str) -> List[schemas.Sensor]:
    """
    Search in elasticsearch with match, prefix and similar.
    """
    # The default search uses the strings as lower case, so convert to lower
    query = query.lower()
    if search_type in ['match', 'prefix']:
        query = {
            'query': {
                search_type: json.loads(query)
            }
        }
    elif search_type == 'similar':
        query = json.loads(query)
        key = list(query)[0]
        value = query[key]
        
        query = {
            "query": {
                "match" : {
                    key : {
                        "query" : value,
                        "fuzziness": 'auto',
                        'operator': 'and'
                    }
                }
            }
        }
    results = []
    query_results = esdb.search('sensors', query, size)
    query_results = [hit['_source'] for hit in query_results['hits']['hits']]
    
    # Loop through the query_result and get all the data from mongo, the resulting
    # list (results) will contain a list of Sensors (schemas.Sensor)
    for doc in query_results:
        mongo_sensor = get_sensor_mongo(mongodb=mongodb, name=doc['name'], collection=doc['type'])
        db_sensor = get_sensor_by_name(db=db, name=doc['name'])
        mongo_sensor.update({'id': db_sensor.id})
        results.append(mongo_sensor)
    
    return results

def get_sensors_near(mongodb: MongoDBClient, latitude: float, longitude: float, radius: float) -> List:
    return mongodb.findNear(latitude, longitude, radius)
