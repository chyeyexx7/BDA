from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.redis_client import RedisClient
from app.mongodb_client import MongoDBClient
from app.elasticsearch_client import ElasticsearchClient 
from app.timescale import Timescale
from . import models, schemas, repository

# Dependency to get db session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_timescale():
    ts = Timescale()
    try:
        yield ts
    finally:
        ts.close()

# Dependency to get redis client
def get_redis_client():
    redis = RedisClient(host="redis")
    try:
        yield redis
    finally:
        redis.close()

# Dependency to get mongodb client
def get_mongodb_client():
    mongodb = MongoDBClient(host="mongodb")
    try:
        yield mongodb
    finally:
        mongodb.close()

# Dependency to get mongodb client
def get_elastic_search():
    es = ElasticsearchClient(host="elasticsearch")
    try:
        yield es
    finally:
        es.close()


router = APIRouter(
    prefix="/sensors",
    responses={404: {"description": "Not found"}},
    tags=["sensors"],
)


# 🙋🏽‍♀️ Add here the route to get a list of sensors near to a given location
@router.get("/near")
def get_sensors_near(
        latitude: float, 
        longitude: float, 
        radius: float, 
        db: Session = Depends(get_db), 
        mongodb_client: MongoDBClient = Depends(get_mongodb_client),
        redis_client: RedisClient = Depends(get_redis_client)
    ):
    """
    Returns a list of sensors sorted by ascending order (distance).
    Because we have three data bases, in order to be able to extraft closest sensors from mongodb,
    firstly we have to get the sensors from mongodb, secondly use the 'name' inside mongodb documents
    to query in postgresql which has the index 'name'. Lastly, use the 'sensor_id' from postgresql
    to query in redis.
    """
    mongo_sensors = repository.get_sensors_near(mongodb=mongodb_client, latitude=latitude, longitude=longitude, radius=radius)
    if not mongo_sensors:
        raise HTTPException(status_code=404, detail="No sensors in data base")
    # Iterate over the mongo sensors and get sensor from postgresql, because it has the sensor_id
    sensors = [repository.get_sensor_by_name(db, sensor['name']) for sensor in mongo_sensors]
    # Iterate over the sensors above and get data from redis with key sensor_id
    for sensor in sensors:
        sensor_data = sensor.__dict__
        db_sensordata = repository.get_data(redis=redis_client, sensor_id=sensor_data['id'])
        sensor_data.update(db_sensordata)
        
    return sensors


# 🙋🏽‍♀️ Add here the route to search sensors by query to Elasticsearch
# Parameters:
# - query: string to search
# - size (optional): number of results to return
# - search_type (optional): type of search to perform
# - db: database session
# - mongodb_client: mongodb client
@router.get("/search")
def search_sensors(
        query: str,
        size: int = 10,
        search_type: str = "match",
        db: Session = Depends(get_db), 
        mongodb_client: MongoDBClient = Depends(get_mongodb_client), 
        es: ElasticsearchClient = Depends(get_elastic_search)
    ):
    """
    Returns a list of sensors given a search_type and the query to match.
    Raise exception if there are no sensors that matches the query
    """
    results = repository.search_sensors(db=db, mongodb=mongodb_client, esdb=es, query=query, size=size, search_type=search_type)
    if not results:
        raise HTTPException(status_code=404, detail="There are no sensors that matches your query")
    
    return results

# 🙋🏽‍♀️ Add here the route to get all sensors
@router.get("")
def get_sensors(db: Session = Depends(get_db)):
    return repository.get_sensors(db)


# 🙋🏽‍♀️ Add here the route to create a sensor
@router.post("")
def create_sensor(
        sensor: schemas.SensorCreate,
        db: Session = Depends(get_db),
        mongodb_client: MongoDBClient = Depends(get_mongodb_client), 
        es_client = Depends(get_elastic_search)
    ):
    """
    Create a new sensor if it does not exist.
    """
    db_sensor = repository.get_sensor_by_name(db, sensor.name)
    if db_sensor:
        raise HTTPException(status_code=400, detail="Sensor with same name already registered")
    
    return repository.create_sensor(db=db, sensor=sensor, mongodb=mongodb_client, esdb=es_client)

# 🙋🏽‍♀️ Add here the route to get a sensor by id
@router.get("/{sensor_id}")
def get_sensor(
        sensor_id: int, 
        db: Session = Depends(get_db), 
        mongodb_client: MongoDBClient = Depends(get_mongodb_client)
    ):
    """
    This API returns the data from MongoDB and Sensor
    """
    db_sensor = repository.get_sensor(db, sensor_id)
    if db_sensor is None:
        raise HTTPException(status_code=404, detail="Sensor not found")
    mongo_sensor = repository.get_sensor_mongo(mongodb=mongodb_client, 
                                            name=db_sensor.__dict__['name'], 
                                            collection=db_sensor.__dict__['type']
                                            )
    mongo_sensor.update({'id': db_sensor.id})
    
    return mongo_sensor

# 🙋🏽‍♀️ Add here the route to delete a sensor
@router.delete("/{sensor_id}")
def delete_sensor(
        sensor_id: int, 
        db: Session = Depends(get_db), 
        redis_client: RedisClient = Depends(get_redis_client), 
        mongodb_client: MongoDBClient = Depends(get_mongodb_client), 
        es: ElasticsearchClient = Depends(get_elastic_search),
        ts_client: Timescale = Depends(get_timescale)
    ):
    """
    Delete the sensor and its data if the sensor exists
    """
    db_sensor = repository.get_sensor(db, sensor_id)
    # Check if the sensor exist
    if db_sensor is None:
        raise HTTPException(status_code=404, detail="Sensor not found")
    
    return repository.delete_sensor(db=db, mongodb=mongodb_client, esdb=es, redis=redis_client, sensor_id=sensor_id, ts=ts_client)
    

# 🙋🏽‍♀️ Add here the route to update a sensor
@router.post("/{sensor_id}/data")
def record_data(
        sensor_id: int,
        data: schemas.SensorData, 
        db: Session = Depends(get_db), 
        redis_client: RedisClient = Depends(get_redis_client), 
        ts_client: Timescale = Depends(get_timescale)
    ):
    """
    Store dynamic data in redis and timescale if the sensor exists
    """
    db_sensor = repository.get_sensor(db, sensor_id)
    if db_sensor is None:
        raise HTTPException(status_code=404, detail="Sensor not found")
    
    return repository.record_data(redis=redis_client, ts=ts_client, sensor_id=sensor_id, data=data)

# 🙋🏽‍♀️ Add here the route to get data from a sensor
@router.get("/{sensor_id}/data")
# TODO return data from redis if no kwargsm else return from timescale
def get_data(
        sensor_id: int, 
        from_date: str = Query(None, alias='from'), 
        end_date: str = Query(None, alias='to'), 
        bucket: str = Query(None, alias='bucket'),
        db: Session = Depends(get_db), 
        redis_client: RedisClient = Depends(get_redis_client), 
        ts_client: Timescale = Depends(get_timescale)
    ):    
    """
    In order to get all the data, first we have to query the sensor which contains
    the sensor name and sensor_id stored in the model, then query the dynamic
    data from redis client if no time range is introduced. Otherswise, query from Timescale
    """
    db_sensor = repository.get_sensor(db, sensor_id)
    if db_sensor is None:
        raise HTTPException(status_code=404, detail="Sensor not found")
    
    if from_date is not None and end_date is not None and bucket is not None:
        db_sensordata = repository.get_ts_data(ts=ts_client, sensor_id=sensor_id, from_date=from_date, end_date=end_date, bucket=bucket)
    else:
        db_sensordata = repository.get_data(redis=redis_client, sensor_id=sensor_id)

    return db_sensordata
