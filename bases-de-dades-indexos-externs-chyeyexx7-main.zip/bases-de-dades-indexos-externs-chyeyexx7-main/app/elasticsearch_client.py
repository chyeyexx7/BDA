from elasticsearch import Elasticsearch

class ElasticsearchClient:
    def __init__(self, host="localhost", port="9200"):
        self.host = host
        self.port = port
        self.client = Elasticsearch(["http://"+self.host+":"+self.port])

    def init_index(self, index_name):
        # Define the mapping for the index
        mapping = {
            'properties': {
                'type': {'type': 'text'},
                'description': {'type': 'text'},
                'name': {'type': 'text'}
            }
        }
        # Create the index
        self.create_index(index_name)
        self.create_mapping(index_name, mapping)

    def ping(self):
        return self.client.ping()
    
    def clearIndex(self, index_name):
        if self.client.indices.exists(index=index_name):
            # If the index exists, delete it
            return self.client.indices.delete(index=index_name)
        else:
            # If the index does not exist, do nothing
            return None
    
    def close(self):
        self.client.close()

    def create_index(self, index_name):
        return self.client.indices.create(index=index_name)
    
    def create_mapping(self, index_name, mapping):
        # body is deprecated, so use individual parameters instead
        return self.client.indices.put_mapping(index=index_name, properties=mapping['properties'])
    
    def search(self, index_name, query, size=10):
        return self.client.search(index=index_name, query=query['query'], size=size)
    
    def index_document(self, index_name, document):
        # Create index if it does not exist
        if not self.client.indices.exists(index=index_name):
            self.init_index(index_name)
        return self.client.index(index=index_name, document=document)
    
    def delete_document(self, index_name, sensor_name):
        # Delete the document from index
        if self.client.indices.exists(index=index_name):
            # If the index exists, delete the document that matches
            query = {
                "query": {
                    "match": {
                        'name': sensor_name
                    }
                }
            }
            self.client.delete_by_query(index=index_name, body=query)


    
    
    
